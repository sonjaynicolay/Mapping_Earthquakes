// API key
const API_KEY = "pk.eyJ1Ijoic29uamF5bmljb2xheSIsImEiOiJja2h2YXo4bnkxZHUzMnlxcDJ3c241ZXV3In0.VptL3TuGuPf2pC67EBijvg"